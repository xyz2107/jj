import {
    Gc as Ne
} from "./chunk-5MZXJYZL.js";
var Ge = e => e.certifications,
    Rr = Ne(Ge, e => e && e.loading),
    Tr = Ne(Ge, e => e && e.certifications),
    Dr = Ne(Ge, e => e && e.errors);

function he(e) {
    let i = e.length;
    for (; --i >= 0;) e[i] = 0
}
var Pi = 0,
    _i = 1,
    Xi = 2,
    Yi = 3,
    Gi = 258,
    gt = 29,
    Re = 256,
    ve = Re + 1 + gt,
    fe = 30,
    pt = 19,
    hi = 2 * ve + 1,
    Q = 15,
    je = 16,
    ji = 7,
    xt = 256,
    di = 16,
    si = 17,
    ci = 18,
    ot = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0]),
    Me = new Uint8Array([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13]),
    Wi = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 7]),
    ui = new Uint8Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]),
    Vi = 512,
    P = new Array((ve + 2) * 2);
he(P);
var ge = new Array(fe * 2);
he(ge);
var ke = new Array(Vi);
he(ke);
var Ee = new Array(Gi - Yi + 1);
he(Ee);
var vt = new Array(gt);
he(vt);
var He = new Array(fe);
he(He);

function We(e, i, t, n, r) {
    this.static_tree = e, this.extra_bits = i, this.extra_base = t, this.elems = n, this.max_length = r, this.has_stree = e && e.length
}
var wi, bi, gi;

function Ve(e, i) {
    this.dyn_tree = e, this.max_code = 0, this.stat_desc = i
}
var pi = e => e < 256 ? ke[e] : ke[256 + (e >>> 7)],
    ye = (e, i) => {
        e.pending_buf[e.pending++] = i & 255, e.pending_buf[e.pending++] = i >>> 8 & 255
    },
    N = (e, i, t) => {
        e.bi_valid > je - t ? (e.bi_buf |= i << e.bi_valid & 65535, ye(e, e.bi_buf), e.bi_buf = i >> je - e.bi_valid, e.bi_valid += t - je) : (e.bi_buf |= i << e.bi_valid & 65535, e.bi_valid += t)
    },
    M = (e, i, t) => {
        N(e, t[i * 2], t[i * 2 + 1])
    },
    xi = (e, i) => {
        let t = 0;
        do t |= e & 1, e >>>= 1, t <<= 1; while (--i > 0);
        return t >>> 1
    },
    Ji = e => {
        e.bi_valid === 16 ? (ye(e, e.bi_buf), e.bi_buf = 0, e.bi_valid = 0) : e.bi_valid >= 8 && (e.pending_buf[e.pending++] = e.bi_buf & 255, e.bi_buf >>= 8, e.bi_valid -= 8)
    },
    Qi = (e, i) => {
        let t = i.dyn_tree,
            n = i.max_code,
            r = i.stat_desc.static_tree,
            a = i.stat_desc.has_stree,
            o = i.stat_desc.extra_bits,
            f = i.stat_desc.extra_base,
            c = i.stat_desc.max_length,
            l, _, y, s, h, u, T = 0;
        for (s = 0; s <= Q; s++) e.bl_count[s] = 0;
        for (t[e.heap[e.heap_max] * 2 + 1] = 0, l = e.heap_max + 1; l < hi; l++) _ = e.heap[l], s = t[t[_ * 2 + 1] * 2 + 1] + 1, s > c && (s = c, T++), t[_ * 2 + 1] = s, !(_ > n) && (e.bl_count[s]++, h = 0, _ >= f && (h = o[_ - f]), u = t[_ * 2], e.opt_len += u * (s + h), a && (e.static_len += u * (r[_ * 2 + 1] + h)));
        if (T !== 0) {
            do {
                for (s = c - 1; e.bl_count[s] === 0;) s--;
                e.bl_count[s]--, e.bl_count[s + 1] += 2, e.bl_count[c]--, T -= 2
            } while (T > 0);
            for (s = c; s !== 0; s--)
                for (_ = e.bl_count[s]; _ !== 0;) y = e.heap[--l], !(y > n) && (t[y * 2 + 1] !== s && (e.opt_len += (s - t[y * 2 + 1]) * t[y * 2], t[y * 2 + 1] = s), _--)
        }
    },
    vi = (e, i, t) => {
        let n = new Array(Q + 1),
            r = 0,
            a, o;
        for (a = 1; a <= Q; a++) r = r + t[a - 1] << 1, n[a] = r;
        for (o = 0; o <= i; o++) {
            let f = e[o * 2 + 1];
            f !== 0 && (e[o * 2] = xi(n[f]++, f))
        }
    },
    qi = () => {
        let e, i, t, n, r, a = new Array(Q + 1);
        for (t = 0, n = 0; n < gt - 1; n++)
            for (vt[n] = t, e = 0; e < 1 << ot[n]; e++) Ee[t++] = n;
        for (Ee[t - 1] = n, r = 0, n = 0; n < 16; n++)
            for (He[n] = r, e = 0; e < 1 << Me[n]; e++) ke[r++] = n;
        for (r >>= 7; n < fe; n++)
            for (He[n] = r << 7, e = 0; e < 1 << Me[n] - 7; e++) ke[256 + r++] = n;
        for (i = 0; i <= Q; i++) a[i] = 0;
        for (e = 0; e <= 143;) P[e * 2 + 1] = 8, e++, a[8]++;
        for (; e <= 255;) P[e * 2 + 1] = 9, e++, a[9]++;
        for (; e <= 279;) P[e * 2 + 1] = 7, e++, a[7]++;
        for (; e <= 287;) P[e * 2 + 1] = 8, e++, a[8]++;
        for (vi(P, ve + 1, a), e = 0; e < fe; e++) ge[e * 2 + 1] = 5, ge[e * 2] = xi(e, 5);
        wi = new We(P, ot, Re + 1, ve, Q), bi = new We(ge, Me, 0, fe, Q), gi = new We(new Array(0), Wi, 0, pt, ji)
    },
    ki = e => {
        let i;
        for (i = 0; i < ve; i++) e.dyn_ltree[i * 2] = 0;
        for (i = 0; i < fe; i++) e.dyn_dtree[i * 2] = 0;
        for (i = 0; i < pt; i++) e.bl_tree[i * 2] = 0;
        e.dyn_ltree[xt * 2] = 1, e.opt_len = e.static_len = 0, e.sym_next = e.matches = 0
    },
    Ei = e => {
        e.bi_valid > 8 ? ye(e, e.bi_buf) : e.bi_valid > 0 && (e.pending_buf[e.pending++] = e.bi_buf), e.bi_buf = 0, e.bi_valid = 0
    },
    zt = (e, i, t, n) => {
        let r = i * 2,
            a = t * 2;
        return e[r] < e[a] || e[r] === e[a] && n[i] <= n[t]
    },
    Je = (e, i, t) => {
        let n = e.heap[t],
            r = t << 1;
        for (; r <= e.heap_len && (r < e.heap_len && zt(i, e.heap[r + 1], e.heap[r], e.depth) && r++, !zt(i, n, e.heap[r], e.depth));) e.heap[t] = e.heap[r], t = r, r <<= 1;
        e.heap[t] = n
    },
    St = (e, i, t) => {
        let n, r, a = 0,
            o, f;
        if (e.sym_next !== 0)
            do n = e.pending_buf[e.sym_buf + a++] & 255, n += (e.pending_buf[e.sym_buf + a++] & 255) << 8, r = e.pending_buf[e.sym_buf + a++], n === 0 ? M(e, r, i) : (o = Ee[r], M(e, o + Re + 1, i), f = ot[o], f !== 0 && (r -= vt[o], N(e, r, f)), n--, o = pi(n), M(e, o, t), f = Me[o], f !== 0 && (n -= He[o], N(e, n, f))); while (a < e.sym_next);
        M(e, xt, i)
    },
    _t = (e, i) => {
        let t = i.dyn_tree,
            n = i.stat_desc.static_tree,
            r = i.stat_desc.has_stree,
            a = i.stat_desc.elems,
            o, f, c = -1,
            l;
        for (e.heap_len = 0, e.heap_max = hi, o = 0; o < a; o++) t[o * 2] !== 0 ? (e.heap[++e.heap_len] = c = o, e.depth[o] = 0) : t[o * 2 + 1] = 0;
        for (; e.heap_len < 2;) l = e.heap[++e.heap_len] = c < 2 ? ++c : 0, t[l * 2] = 1, e.depth[l] = 0, e.opt_len--, r && (e.static_len -= n[l * 2 + 1]);
        for (i.max_code = c, o = e.heap_len >> 1; o >= 1; o--) Je(e, t, o);
        l = a;
        do o = e.heap[1], e.heap[1] = e.heap[e.heap_len--], Je(e, t, 1), f = e.heap[1], e.heap[--e.heap_max] = o, e.heap[--e.heap_max] = f, t[l * 2] = t[o * 2] + t[f * 2], e.depth[l] = (e.depth[o] >= e.depth[f] ? e.depth[o] : e.depth[f]) + 1, t[o * 2 + 1] = t[f * 2 + 1] = l, e.heap[1] = l++, Je(e, t, 1); while (e.heap_len >= 2);
        e.heap[--e.heap_max] = e.heap[1], Qi(e, i), vi(t, c, e.bl_count)
    },
    At = (e, i, t) => {
        let n, r = -1,
            a, o = i[1],
            f = 0,
            c = 7,
            l = 4;
        for (o === 0 && (c = 138, l = 3), i[(t + 1) * 2 + 1] = 65535, n = 0; n <= t; n++) a = o, o = i[(n + 1) * 2 + 1], !(++f < c && a === o) && (f < l ? e.bl_tree[a * 2] += f : a !== 0 ? (a !== r && e.bl_tree[a * 2]++, e.bl_tree[di * 2]++) : f <= 10 ? e.bl_tree[si * 2]++ : e.bl_tree[ci * 2]++, f = 0, r = a, o === 0 ? (c = 138, l = 3) : a === o ? (c = 6, l = 3) : (c = 7, l = 4))
    },
    Rt = (e, i, t) => {
        let n, r = -1,
            a, o = i[1],
            f = 0,
            c = 7,
            l = 4;
        for (o === 0 && (c = 138, l = 3), n = 0; n <= t; n++)
            if (a = o, o = i[(n + 1) * 2 + 1], !(++f < c && a === o)) {
                if (f < l)
                    do M(e, a, e.bl_tree); while (--f !== 0);
                else a !== 0 ? (a !== r && (M(e, a, e.bl_tree), f--), M(e, di, e.bl_tree), N(e, f - 3, 2)) : f <= 10 ? (M(e, si, e.bl_tree), N(e, f - 3, 3)) : (M(e, ci, e.bl_tree), N(e, f - 11, 7));
                f = 0, r = a, o === 0 ? (c = 138, l = 3) : a === o ? (c = 6, l = 3) : (c = 7, l = 4)
            }
    },
    en = e => {
        let i;
        for (At(e, e.dyn_ltree, e.l_desc.max_code), At(e, e.dyn_dtree, e.d_desc.max_code), _t(e, e.bl_desc), i = pt - 1; i >= 3 && e.bl_tree[ui[i] * 2 + 1] === 0; i--);
        return e.opt_len += 3 * (i + 1) + 5 + 5 + 4, i
    },
    tn = (e, i, t, n) => {
        let r;
        for (N(e, i - 257, 5), N(e, t - 1, 5), N(e, n - 4, 4), r = 0; r < n; r++) N(e, e.bl_tree[ui[r] * 2 + 1], 3);
        Rt(e, e.dyn_ltree, i - 1), Rt(e, e.dyn_dtree, t - 1)
    },
    nn = e => {
        let i = 4093624447,
            t;
        for (t = 0; t <= 31; t++, i >>>= 1)
            if (i & 1 && e.dyn_ltree[t * 2] !== 0) return 0;
        if (e.dyn_ltree[18] !== 0 || e.dyn_ltree[20] !== 0 || e.dyn_ltree[26] !== 0) return 1;
        for (t = 32; t < Re; t++)
            if (e.dyn_ltree[t * 2] !== 0) return 1;
        return 0
    },
    Tt = !1,
    an = e => {
        Tt || (qi(), Tt = !0), e.l_desc = new Ve(e.dyn_ltree, wi), e.d_desc = new Ve(e.dyn_dtree, bi), e.bl_desc = new Ve(e.bl_tree, gi), e.bi_buf = 0, e.bi_valid = 0, ki(e)
    },
    yi = (e, i, t, n) => {
        N(e, (Pi << 1) + (n ? 1 : 0), 3), Ei(e), ye(e, t), ye(e, ~t), t && e.pending_buf.set(e.window.subarray(i, i + t), e.pending), e.pending += t
    },
    rn = e => {
        N(e, _i << 1, 3), M(e, xt, P), Ji(e)
    },
    ln = (e, i, t, n) => {
        let r, a, o = 0;
        e.level > 0 ? (e.strm.data_type === 2 && (e.strm.data_type = nn(e)), _t(e, e.l_desc), _t(e, e.d_desc), o = en(e), r = e.opt_len + 3 + 7 >>> 3, a = e.static_len + 3 + 7 >>> 3, a <= r && (r = a)) : r = a = t + 5, t + 4 <= r && i !== -1 ? yi(e, i, t, n) : e.strategy === 4 || a === r ? (N(e, (_i << 1) + (n ? 1 : 0), 3), St(e, P, ge)) : (N(e, (Xi << 1) + (n ? 1 : 0), 3), tn(e, e.l_desc.max_code + 1, e.d_desc.max_code + 1, o + 1), St(e, e.dyn_ltree, e.dyn_dtree)), ki(e), n && Ei(e)
    },
    fn = (e, i, t) => (e.pending_buf[e.sym_buf + e.sym_next++] = i, e.pending_buf[e.sym_buf + e.sym_next++] = i >> 8, e.pending_buf[e.sym_buf + e.sym_next++] = t, i === 0 ? e.dyn_ltree[t * 2]++ : (e.matches++, i--, e.dyn_ltree[(Ee[t] + Re + 1) * 2]++, e.dyn_dtree[pi(i) * 2]++), e.sym_next === e.sym_end),
    on = an,
    _n = yi,
    hn = ln,
    dn = fn,
    sn = rn,
    cn = {
        _tr_init: on,
        _tr_stored_block: _n,
        _tr_flush_block: hn,
        _tr_tally: dn,
        _tr_align: sn
    },
    un = (e, i, t, n) => {
        let r = e & 65535 | 0,
            a = e >>> 16 & 65535 | 0,
            o = 0;
        for (; t !== 0;) {
            o = t > 2e3 ? 2e3 : t, t -= o;
            do r = r + i[n++] | 0, a = a + r | 0; while (--o);
            r %= 65521, a %= 65521
        }
        return r | a << 16 | 0
    },
    me = un,
    wn = () => {
        let e, i = [];
        for (var t = 0; t < 256; t++) {
            e = t;
            for (var n = 0; n < 8; n++) e = e & 1 ? 3988292384 ^ e >>> 1 : e >>> 1;
            i[t] = e
        }
        return i
    },
    bn = new Uint32Array(wn()),
    gn = (e, i, t, n) => {
        let r = bn,
            a = n + t;
        e ^= -1;
        for (let o = n; o < a; o++) e = e >>> 8 ^ r[(e ^ i[o]) & 255];
        return e ^ -1
    },
    Z = gn,
    te = {
        2: "need dictionary",
        1: "stream end",
        0: "",
        "-1": "file error",
        "-2": "stream error",
        "-3": "data error",
        "-4": "insufficient memory",
        "-5": "buffer error",
        "-6": "incompatible version"
    },
    de = {
        Z_NO_FLUSH: 0,
        Z_PARTIAL_FLUSH: 1,
        Z_SYNC_FLUSH: 2,
        Z_FULL_FLUSH: 3,
        Z_FINISH: 4,
        Z_BLOCK: 5,
        Z_TREES: 6,
        Z_OK: 0,
        Z_STREAM_END: 1,
        Z_NEED_DICT: 2,
        Z_ERRNO: -1,
        Z_STREAM_ERROR: -2,
        Z_DATA_ERROR: -3,
        Z_MEM_ERROR: -4,
        Z_BUF_ERROR: -5,
        Z_NO_COMPRESSION: 0,
        Z_BEST_SPEED: 1,
        Z_BEST_COMPRESSION: 9,
        Z_DEFAULT_COMPRESSION: -1,
        Z_FILTERED: 1,
        Z_HUFFMAN_ONLY: 2,
        Z_RLE: 3,
        Z_FIXED: 4,
        Z_DEFAULT_STRATEGY: 0,
        Z_BINARY: 0,
        Z_TEXT: 1,
        Z_UNKNOWN: 2,
        Z_DEFLATED: 8
    },
    {
        _tr_init: pn,
        _tr_stored_block: ht,
        _tr_flush_block: xn,
        _tr_tally: j,
        _tr_align: vn
    } = cn,
    {
        Z_NO_FLUSH: W,
        Z_PARTIAL_FLUSH: kn,
        Z_FULL_FLUSH: En,
        Z_FINISH: C,
        Z_BLOCK: Dt,
        Z_OK: I,
        Z_STREAM_END: Zt,
        Z_STREAM_ERROR: H,
        Z_DATA_ERROR: yn,
        Z_BUF_ERROR: Qe,
        Z_DEFAULT_COMPRESSION: mn,
        Z_FILTERED: zn,
        Z_HUFFMAN_ONLY: Le,
        Z_RLE: Sn,
        Z_FIXED: An,
        Z_DEFAULT_STRATEGY: Rn,
        Z_UNKNOWN: Tn,
        Z_DEFLATED: Pe
    } = de,
    Dn = 9,
    Zn = 15,
    In = 8,
    On = 29,
    Nn = 256,
    dt = Nn + 1 + On,
    Ln = 30,
    Un = 19,
    Cn = 2 * dt + 1,
    $n = 15,
    v = 3,
    G = 258,
    B = G + v + 1,
    Fn = 32,
    oe = 42,
    kt = 57,
    st = 69,
    ct = 73,
    ut = 91,
    wt = 103,
    q = 113,
    we = 666,
    O = 1,
    se = 2,
    ie = 3,
    ce = 4,
    Mn = 3,
    ee = (e, i) => (e.msg = te[i], i),
    It = e => e * 2 - (e > 4 ? 9 : 0),
    Y = e => {
        let i = e.length;
        for (; --i >= 0;) e[i] = 0
    },
    Hn = e => {
        let i, t, n, r = e.w_size;
        i = e.hash_size, n = i;
        do t = e.head[--n], e.head[n] = t >= r ? t - r : 0; while (--i);
        i = r, n = i;
        do t = e.prev[--n], e.prev[n] = t >= r ? t - r : 0; while (--i)
    },
    Bn = (e, i, t) => (i << e.hash_shift ^ t) & e.hash_mask,
    V = Bn,
    L = e => {
        let i = e.state,
            t = i.pending;
        t > e.avail_out && (t = e.avail_out), t !== 0 && (e.output.set(i.pending_buf.subarray(i.pending_out, i.pending_out + t), e.next_out), e.next_out += t, i.pending_out += t, e.total_out += t, e.avail_out -= t, i.pending -= t, i.pending === 0 && (i.pending_out = 0))
    },
    U = (e, i) => {
        xn(e, e.block_start >= 0 ? e.block_start : -1, e.strstart - e.block_start, i), e.block_start = e.strstart, L(e.strm)
    },
    z = (e, i) => {
        e.pending_buf[e.pending++] = i
    },
    ue = (e, i) => {
        e.pending_buf[e.pending++] = i >>> 8 & 255, e.pending_buf[e.pending++] = i & 255
    },
    bt = (e, i, t, n) => {
        let r = e.avail_in;
        return r > n && (r = n), r === 0 ? 0 : (e.avail_in -= r, i.set(e.input.subarray(e.next_in, e.next_in + r), t), e.state.wrap === 1 ? e.adler = me(e.adler, i, r, t) : e.state.wrap === 2 && (e.adler = Z(e.adler, i, r, t)), e.next_in += r, e.total_in += r, r)
    },
    mi = (e, i) => {
        let t = e.max_chain_length,
            n = e.strstart,
            r, a, o = e.prev_length,
            f = e.nice_match,
            c = e.strstart > e.w_size - B ? e.strstart - (e.w_size - B) : 0,
            l = e.window,
            _ = e.w_mask,
            y = e.prev,
            s = e.strstart + G,
            h = l[n + o - 1],
            u = l[n + o];
        e.prev_length >= e.good_match && (t >>= 2), f > e.lookahead && (f = e.lookahead);
        do
            if (r = i, !(l[r + o] !== u || l[r + o - 1] !== h || l[r] !== l[n] || l[++r] !== l[n + 1])) {
                n += 2, r++;
                do; while (l[++n] === l[++r] && l[++n] === l[++r] && l[++n] === l[++r] && l[++n] === l[++r] && l[++n] === l[++r] && l[++n] === l[++r] && l[++n] === l[++r] && l[++n] === l[++r] && n < s);
                if (a = G - (s - n), n = s - G, a > o) {
                    if (e.match_start = i, o = a, a >= f) break;
                    h = l[n + o - 1], u = l[n + o]
                }
            }
        while ((i = y[i & _]) > c && --t !== 0);
        return o <= e.lookahead ? o : e.lookahead
    },
    _e = e => {
        let i = e.w_size,
            t, n, r;
        do {
            if (n = e.window_size - e.lookahead - e.strstart, e.strstart >= i + (i - B) && (e.window.set(e.window.subarray(i, i + i - n), 0), e.match_start -= i, e.strstart -= i, e.block_start -= i, e.insert > e.strstart && (e.insert = e.strstart), Hn(e), n += i), e.strm.avail_in === 0) break;
            if (t = bt(e.strm, e.window, e.strstart + e.lookahead, n), e.lookahead += t, e.lookahead + e.insert >= v)
                for (r = e.strstart - e.insert, e.ins_h = e.window[r], e.ins_h = V(e, e.ins_h, e.window[r + 1]); e.insert && (e.ins_h = V(e, e.ins_h, e.window[r + v - 1]), e.prev[r & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = r, r++, e.insert--, !(e.lookahead + e.insert < v)););
        } while (e.lookahead < B && e.strm.avail_in !== 0)
    },
    zi = (e, i) => {
        let t = e.pending_buf_size - 5 > e.w_size ? e.w_size : e.pending_buf_size - 5,
            n, r, a, o = 0,
            f = e.strm.avail_in;
        do {
            if (n = 65535, a = e.bi_valid + 42 >> 3, e.strm.avail_out < a || (a = e.strm.avail_out - a, r = e.strstart - e.block_start, n > r + e.strm.avail_in && (n = r + e.strm.avail_in), n > a && (n = a), n < t && (n === 0 && i !== C || i === W || n !== r + e.strm.avail_in))) break;
            o = i === C && n === r + e.strm.avail_in ? 1 : 0, ht(e, 0, 0, o), e.pending_buf[e.pending - 4] = n, e.pending_buf[e.pending - 3] = n >> 8, e.pending_buf[e.pending - 2] = ~n, e.pending_buf[e.pending - 1] = ~n >> 8, L(e.strm), r && (r > n && (r = n), e.strm.output.set(e.window.subarray(e.block_start, e.block_start + r), e.strm.next_out), e.strm.next_out += r, e.strm.avail_out -= r, e.strm.total_out += r, e.block_start += r, n -= r), n && (bt(e.strm, e.strm.output, e.strm.next_out, n), e.strm.next_out += n, e.strm.avail_out -= n, e.strm.total_out += n)
        } while (o === 0);
        return f -= e.strm.avail_in, f && (f >= e.w_size ? (e.matches = 2, e.window.set(e.strm.input.subarray(e.strm.next_in - e.w_size, e.strm.next_in), 0), e.strstart = e.w_size, e.insert = e.strstart) : (e.window_size - e.strstart <= f && (e.strstart -= e.w_size, e.window.set(e.window.subarray(e.w_size, e.w_size + e.strstart), 0), e.matches < 2 && e.matches++, e.insert > e.strstart && (e.insert = e.strstart)), e.window.set(e.strm.input.subarray(e.strm.next_in - f, e.strm.next_in), e.strstart), e.strstart += f, e.insert += f > e.w_size - e.insert ? e.w_size - e.insert : f), e.block_start = e.strstart), e.high_water < e.strstart && (e.high_water = e.strstart), o ? ce : i !== W && i !== C && e.strm.avail_in === 0 && e.strstart === e.block_start ? se : (a = e.window_size - e.strstart, e.strm.avail_in > a && e.block_start >= e.w_size && (e.block_start -= e.w_size, e.strstart -= e.w_size, e.window.set(e.window.subarray(e.w_size, e.w_size + e.strstart), 0), e.matches < 2 && e.matches++, a += e.w_size, e.insert > e.strstart && (e.insert = e.strstart)), a > e.strm.avail_in && (a = e.strm.avail_in), a && (bt(e.strm, e.window, e.strstart, a), e.strstart += a, e.insert += a > e.w_size - e.insert ? e.w_size - e.insert : a), e.high_water < e.strstart && (e.high_water = e.strstart), a = e.bi_valid + 42 >> 3, a = e.pending_buf_size - a > 65535 ? 65535 : e.pending_buf_size - a, t = a > e.w_size ? e.w_size : a, r = e.strstart - e.block_start, (r >= t || (r || i === C) && i !== W && e.strm.avail_in === 0 && r <= a) && (n = r > a ? a : r, o = i === C && e.strm.avail_in === 0 && n === r ? 1 : 0, ht(e, e.block_start, n, o), e.block_start += n, L(e.strm)), o ? ie : O)
    },
    qe = (e, i) => {
        let t, n;
        for (;;) {
            if (e.lookahead < B) {
                if (_e(e), e.lookahead < B && i === W) return O;
                if (e.lookahead === 0) break
            }
            if (t = 0, e.lookahead >= v && (e.ins_h = V(e, e.ins_h, e.window[e.strstart + v - 1]), t = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart), t !== 0 && e.strstart - t <= e.w_size - B && (e.match_length = mi(e, t)), e.match_length >= v)
                if (n = j(e, e.strstart - e.match_start, e.match_length - v), e.lookahead -= e.match_length, e.match_length <= e.max_lazy_match && e.lookahead >= v) {
                    e.match_length--;
                    do e.strstart++, e.ins_h = V(e, e.ins_h, e.window[e.strstart + v - 1]), t = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart; while (--e.match_length !== 0);
                    e.strstart++
                } else e.strstart += e.match_length, e.match_length = 0, e.ins_h = e.window[e.strstart], e.ins_h = V(e, e.ins_h, e.window[e.strstart + 1]);
            else n = j(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++;
            if (n && (U(e, !1), e.strm.avail_out === 0)) return O
        }
        return e.insert = e.strstart < v - 1 ? e.strstart : v - 1, i === C ? (U(e, !0), e.strm.avail_out === 0 ? ie : ce) : e.sym_next && (U(e, !1), e.strm.avail_out === 0) ? O : se
    },
    re = (e, i) => {
        let t, n, r;
        for (;;) {
            if (e.lookahead < B) {
                if (_e(e), e.lookahead < B && i === W) return O;
                if (e.lookahead === 0) break
            }
            if (t = 0, e.lookahead >= v && (e.ins_h = V(e, e.ins_h, e.window[e.strstart + v - 1]), t = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart), e.prev_length = e.match_length, e.prev_match = e.match_start, e.match_length = v - 1, t !== 0 && e.prev_length < e.max_lazy_match && e.strstart - t <= e.w_size - B && (e.match_length = mi(e, t), e.match_length <= 5 && (e.strategy === zn || e.match_length === v && e.strstart - e.match_start > 4096) && (e.match_length = v - 1)), e.prev_length >= v && e.match_length <= e.prev_length) {
                r = e.strstart + e.lookahead - v, n = j(e, e.strstart - 1 - e.prev_match, e.prev_length - v), e.lookahead -= e.prev_length - 1, e.prev_length -= 2;
                do ++e.strstart <= r && (e.ins_h = V(e, e.ins_h, e.window[e.strstart + v - 1]), t = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart); while (--e.prev_length !== 0);
                if (e.match_available = 0, e.match_length = v - 1, e.strstart++, n && (U(e, !1), e.strm.avail_out === 0)) return O
            } else if (e.match_available) {
                if (n = j(e, 0, e.window[e.strstart - 1]), n && U(e, !1), e.strstart++, e.lookahead--, e.strm.avail_out === 0) return O
            } else e.match_available = 1, e.strstart++, e.lookahead--
        }
        return e.match_available && (n = j(e, 0, e.window[e.strstart - 1]), e.match_available = 0), e.insert = e.strstart < v - 1 ? e.strstart : v - 1, i === C ? (U(e, !0), e.strm.avail_out === 0 ? ie : ce) : e.sym_next && (U(e, !1), e.strm.avail_out === 0) ? O : se
    },
    Kn = (e, i) => {
        let t, n, r, a, o = e.window;
        for (;;) {
            if (e.lookahead <= G) {
                if (_e(e), e.lookahead <= G && i === W) return O;
                if (e.lookahead === 0) break
            }
            if (e.match_length = 0, e.lookahead >= v && e.strstart > 0 && (r = e.strstart - 1, n = o[r], n === o[++r] && n === o[++r] && n === o[++r])) {
                a = e.strstart + G;
                do; while (n === o[++r] && n === o[++r] && n === o[++r] && n === o[++r] && n === o[++r] && n === o[++r] && n === o[++r] && n === o[++r] && r < a);
                e.match_length = G - (a - r), e.match_length > e.lookahead && (e.match_length = e.lookahead)
            }
            if (e.match_length >= v ? (t = j(e, 1, e.match_length - v), e.lookahead -= e.match_length, e.strstart += e.match_length, e.match_length = 0) : (t = j(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++), t && (U(e, !1), e.strm.avail_out === 0)) return O
        }
        return e.insert = 0, i === C ? (U(e, !0), e.strm.avail_out === 0 ? ie : ce) : e.sym_next && (U(e, !1), e.strm.avail_out === 0) ? O : se
    },
    Pn = (e, i) => {
        let t;
        for (;;) {
            if (e.lookahead === 0 && (_e(e), e.lookahead === 0)) {
                if (i === W) return O;
                break
            }
            if (e.match_length = 0, t = j(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++, t && (U(e, !1), e.strm.avail_out === 0)) return O
        }
        return e.insert = 0, i === C ? (U(e, !0), e.strm.avail_out === 0 ? ie : ce) : e.sym_next && (U(e, !1), e.strm.avail_out === 0) ? O : se
    };

function F(e, i, t, n, r) {
    this.good_length = e, this.max_lazy = i, this.nice_length = t, this.max_chain = n, this.func = r
}
var be = [new F(0, 0, 0, 0, zi), new F(4, 4, 8, 4, qe), new F(4, 5, 16, 8, qe), new F(4, 6, 32, 32, qe), new F(4, 4, 16, 16, re), new F(8, 16, 32, 32, re), new F(8, 16, 128, 128, re), new F(8, 32, 128, 256, re), new F(32, 128, 258, 1024, re), new F(32, 258, 258, 4096, re)],
    Xn = e => {
        e.window_size = 2 * e.w_size, Y(e.head), e.max_lazy_match = be[e.level].max_lazy, e.good_match = be[e.level].good_length, e.nice_match = be[e.level].nice_length, e.max_chain_length = be[e.level].max_chain, e.strstart = 0, e.block_start = 0, e.lookahead = 0, e.insert = 0, e.match_length = e.prev_length = v - 1, e.match_available = 0, e.ins_h = 0
    };

function Yn() {
    this.strm = null, this.status = 0, this.pending_buf = null, this.pending_buf_size = 0, this.pending_out = 0, this.pending = 0, this.wrap = 0, this.gzhead = null, this.gzindex = 0, this.method = Pe, this.last_flush = -1, this.w_size = 0, this.w_bits = 0, this.w_mask = 0, this.window = null, this.window_size = 0, this.prev = null, this.head = null, this.ins_h = 0, this.hash_size = 0, this.hash_bits = 0, this.hash_mask = 0, this.hash_shift = 0, this.block_start = 0, this.match_length = 0, this.prev_match = 0, this.match_available = 0, this.strstart = 0, this.match_start = 0, this.lookahead = 0, this.prev_length = 0, this.max_chain_length = 0, this.max_lazy_match = 0, this.level = 0, this.strategy = 0, this.good_match = 0, this.nice_match = 0, this.dyn_ltree = new Uint16Array(Cn * 2), this.dyn_dtree = new Uint16Array((2 * Ln + 1) * 2), this.bl_tree = new Uint16Array((2 * Un + 1) * 2), Y(this.dyn_ltree), Y(this.dyn_dtree), Y(this.bl_tree), this.l_desc = null, this.d_desc = null, this.bl_desc = null, this.bl_count = new Uint16Array($n + 1), this.heap = new Uint16Array(2 * dt + 1), Y(this.heap), this.heap_len = 0, this.heap_max = 0, this.depth = new Uint16Array(2 * dt + 1), Y(this.depth), this.sym_buf = 0, this.lit_bufsize = 0, this.sym_next = 0, this.sym_end = 0, this.opt_len = 0, this.static_len = 0, this.matches = 0, this.insert = 0, this.bi_buf = 0, this.bi_valid = 0
}
var Te = e => {
        if (!e) return 1;
        let i = e.state;
        return !i || i.strm !== e || i.status !== oe && i.status !== kt && i.status !== st && i.status !== ct && i.status !== ut && i.status !== wt && i.status !== q && i.status !== we ? 1 : 0
    },
    Si = e => {
        if (Te(e)) return ee(e, H);
        e.total_in = e.total_out = 0, e.data_type = Tn;
        let i = e.state;
        return i.pending = 0, i.pending_out = 0, i.wrap < 0 && (i.wrap = -i.wrap), i.status = i.wrap === 2 ? kt : i.wrap ? oe : q, e.adler = i.wrap === 2 ? 0 : 1, i.last_flush = -2, pn(i), I
    },
    Ai = e => {
        let i = Si(e);
        return i === I && Xn(e.state), i
    },
    Gn = (e, i) => Te(e) || e.state.wrap !== 2 ? H : (e.state.gzhead = i, I),
    Ri = (e, i, t, n, r, a) => {
        if (!e) return H;
        let o = 1;
        if (i === mn && (i = 6), n < 0 ? (o = 0, n = -n) : n > 15 && (o = 2, n -= 16), r < 1 || r > Dn || t !== Pe || n < 8 || n > 15 || i < 0 || i > 9 || a < 0 || a > An || n === 8 && o !== 1) return ee(e, H);
        n === 8 && (n = 9);
        let f = new Yn;
        return e.state = f, f.strm = e, f.status = oe, f.wrap = o, f.gzhead = null, f.w_bits = n, f.w_size = 1 << f.w_bits, f.w_mask = f.w_size - 1, f.hash_bits = r + 7, f.hash_size = 1 << f.hash_bits, f.hash_mask = f.hash_size - 1, f.hash_shift = ~~((f.hash_bits + v - 1) / v), f.window = new Uint8Array(f.w_size * 2), f.head = new Uint16Array(f.hash_size), f.prev = new Uint16Array(f.w_size), f.lit_bufsize = 1 << r + 6, f.pending_buf_size = f.lit_bufsize * 4, f.pending_buf = new Uint8Array(f.pending_buf_size), f.sym_buf = f.lit_bufsize, f.sym_end = (f.lit_bufsize - 1) * 3, f.level = i, f.strategy = a, f.method = t, Ai(e)
    },
    jn = (e, i) => Ri(e, i, Pe, Zn, In, Rn),
    Wn = (e, i) => {
        if (Te(e) || i > Dt || i < 0) return e ? ee(e, H) : H;
        let t = e.state;
        if (!e.output || e.avail_in !== 0 && !e.input || t.status === we && i !== C) return ee(e, e.avail_out === 0 ? Qe : H);
        let n = t.last_flush;
        if (t.last_flush = i, t.pending !== 0) {
            if (L(e), e.avail_out === 0) return t.last_flush = -1, I
        } else if (e.avail_in === 0 && It(i) <= It(n) && i !== C) return ee(e, Qe);
        if (t.status === we && e.avail_in !== 0) return ee(e, Qe);
        if (t.status === oe && t.wrap === 0 && (t.status = q), t.status === oe) {
            let r = Pe + (t.w_bits - 8 << 4) << 8,
                a = -1;
            if (t.strategy >= Le || t.level < 2 ? a = 0 : t.level < 6 ? a = 1 : t.level === 6 ? a = 2 : a = 3, r |= a << 6, t.strstart !== 0 && (r |= Fn), r += 31 - r % 31, ue(t, r), t.strstart !== 0 && (ue(t, e.adler >>> 16), ue(t, e.adler & 65535)), e.adler = 1, t.status = q, L(e), t.pending !== 0) return t.last_flush = -1, I
        }
        if (t.status === kt) {
            if (e.adler = 0, z(t, 31), z(t, 139), z(t, 8), t.gzhead) z(t, (t.gzhead.text ? 1 : 0) + (t.gzhead.hcrc ? 2 : 0) + (t.gzhead.extra ? 4 : 0) + (t.gzhead.name ? 8 : 0) + (t.gzhead.comment ? 16 : 0)), z(t, t.gzhead.time & 255), z(t, t.gzhead.time >> 8 & 255), z(t, t.gzhead.time >> 16 & 255), z(t, t.gzhead.time >> 24 & 255), z(t, t.level === 9 ? 2 : t.strategy >= Le || t.level < 2 ? 4 : 0), z(t, t.gzhead.os & 255), t.gzhead.extra && t.gzhead.extra.length && (z(t, t.gzhead.extra.length & 255), z(t, t.gzhead.extra.length >> 8 & 255)), t.gzhead.hcrc && (e.adler = Z(e.adler, t.pending_buf, t.pending, 0)), t.gzindex = 0, t.status = st;
            else if (z(t, 0), z(t, 0), z(t, 0), z(t, 0), z(t, 0), z(t, t.level === 9 ? 2 : t.strategy >= Le || t.level < 2 ? 4 : 0), z(t, Mn), t.status = q, L(e), t.pending !== 0) return t.last_flush = -1, I
        }
        if (t.status === st) {
            if (t.gzhead.extra) {
                let r = t.pending,
                    a = (t.gzhead.extra.length & 65535) - t.gzindex;
                for (; t.pending + a > t.pending_buf_size;) {
                    let f = t.pending_buf_size - t.pending;
                    if (t.pending_buf.set(t.gzhead.extra.subarray(t.gzindex, t.gzindex + f), t.pending), t.pending = t.pending_buf_size, t.gzhead.hcrc && t.pending > r && (e.adler = Z(e.adler, t.pending_buf, t.pending - r, r)), t.gzindex += f, L(e), t.pending !== 0) return t.last_flush = -1, I;
                    r = 0, a -= f
                }
                let o = new Uint8Array(t.gzhead.extra);
                t.pending_buf.set(o.subarray(t.gzindex, t.gzindex + a), t.pending), t.pending += a, t.gzhead.hcrc && t.pending > r && (e.adler = Z(e.adler, t.pending_buf, t.pending - r, r)), t.gzindex = 0
            }
            t.status = ct
        }
        if (t.status === ct) {
            if (t.gzhead.name) {
                let r = t.pending,
                    a;
                do {
                    if (t.pending === t.pending_buf_size) {
                        if (t.gzhead.hcrc && t.pending > r && (e.adler = Z(e.adler, t.pending_buf, t.pending - r, r)), L(e), t.pending !== 0) return t.last_flush = -1, I;
                        r = 0
                    }
                    t.gzindex < t.gzhead.name.length ? a = t.gzhead.name.charCodeAt(t.gzindex++) & 255 : a = 0, z(t, a)
                } while (a !== 0);
                t.gzhead.hcrc && t.pending > r && (e.adler = Z(e.adler, t.pending_buf, t.pending - r, r)), t.gzindex = 0
            }
            t.status = ut
        }
        if (t.status === ut) {
            if (t.gzhead.comment) {
                let r = t.pending,
                    a;
                do {
                    if (t.pending === t.pending_buf_size) {
                        if (t.gzhead.hcrc && t.pending > r && (e.adler = Z(e.adler, t.pending_buf, t.pending - r, r)), L(e), t.pending !== 0) return t.last_flush = -1, I;
                        r = 0
                    }
                    t.gzindex < t.gzhead.comment.length ? a = t.gzhead.comment.charCodeAt(t.gzindex++) & 255 : a = 0, z(t, a)
                } while (a !== 0);
                t.gzhead.hcrc && t.pending > r && (e.adler = Z(e.adler, t.pending_buf, t.pending - r, r))
            }
            t.status = wt
        }
        if (t.status === wt) {
            if (t.gzhead.hcrc) {
                if (t.pending + 2 > t.pending_buf_size && (L(e), t.pending !== 0)) return t.last_flush = -1, I;
                z(t, e.adler & 255), z(t, e.adler >> 8 & 255), e.adler = 0
            }
            if (t.status = q, L(e), t.pending !== 0) return t.last_flush = -1, I
        }
        if (e.avail_in !== 0 || t.lookahead !== 0 || i !== W && t.status !== we) {
            let r = t.level === 0 ? zi(t, i) : t.strategy === Le ? Pn(t, i) : t.strategy === Sn ? Kn(t, i) : be[t.level].func(t, i);
            if ((r === ie || r === ce) && (t.status = we), r === O || r === ie) return e.avail_out === 0 && (t.last_flush = -1), I;
            if (r === se && (i === kn ? vn(t) : i !== Dt && (ht(t, 0, 0, !1), i === En && (Y(t.head), t.lookahead === 0 && (t.strstart = 0, t.block_start = 0, t.insert = 0))), L(e), e.avail_out === 0)) return t.last_flush = -1, I
        }
        return i !== C ? I : t.wrap <= 0 ? Zt : (t.wrap === 2 ? (z(t, e.adler & 255), z(t, e.adler >> 8 & 255), z(t, e.adler >> 16 & 255), z(t, e.adler >> 24 & 255), z(t, e.total_in & 255), z(t, e.total_in >> 8 & 255), z(t, e.total_in >> 16 & 255), z(t, e.total_in >> 24 & 255)) : (ue(t, e.adler >>> 16), ue(t, e.adler & 65535)), L(e), t.wrap > 0 && (t.wrap = -t.wrap), t.pending !== 0 ? I : Zt)
    },
    Vn = e => {
        if (Te(e)) return H;
        let i = e.state.status;
        return e.state = null, i === q ? ee(e, yn) : I
    },
    Jn = (e, i) => {
        let t = i.length;
        if (Te(e)) return H;
        let n = e.state,
            r = n.wrap;
        if (r === 2 || r === 1 && n.status !== oe || n.lookahead) return H;
        if (r === 1 && (e.adler = me(e.adler, i, t, 0)), n.wrap = 0, t >= n.w_size) {
            r === 0 && (Y(n.head), n.strstart = 0, n.block_start = 0, n.insert = 0);
            let c = new Uint8Array(n.w_size);
            c.set(i.subarray(t - n.w_size, t), 0), i = c, t = n.w_size
        }
        let a = e.avail_in,
            o = e.next_in,
            f = e.input;
        for (e.avail_in = t, e.next_in = 0, e.input = i, _e(n); n.lookahead >= v;) {
            let c = n.strstart,
                l = n.lookahead - (v - 1);
            do n.ins_h = V(n, n.ins_h, n.window[c + v - 1]), n.prev[c & n.w_mask] = n.head[n.ins_h], n.head[n.ins_h] = c, c++; while (--l);
            n.strstart = c, n.lookahead = v - 1, _e(n)
        }
        return n.strstart += n.lookahead, n.block_start = n.strstart, n.insert = n.lookahead, n.lookahead = 0, n.match_length = n.prev_length = v - 1, n.match_available = 0, e.next_in = o, e.input = f, e.avail_in = a, n.wrap = r, I
    },
    Qn = jn,
    qn = Ri,
    ea = Ai,
    ta = Si,
    ia = Gn,
    na = Wn,
    aa = Vn,
    ra = Jn,
    la = "pako deflate (from Nodeca project)",
    pe = {
        deflateInit: Qn,
        deflateInit2: qn,
        deflateReset: ea,
        deflateResetKeep: ta,
        deflateSetHeader: ia,
        deflate: na,
        deflateEnd: aa,
        deflateSetDictionary: ra,
        deflateInfo: la
    },
    fa = (e, i) => Object.prototype.hasOwnProperty.call(e, i),
    oa = function(e) {
        let i = Array.prototype.slice.call(arguments, 1);
        for (; i.length;) {
            let t = i.shift();
            if (t) {
                if (typeof t != "object") throw new TypeError(t + "must be non-object");
                for (let n in t) fa(t, n) && (e[n] = t[n])
            }
        }
        return e
    },
    _a = e => {
        let i = 0;
        for (let n = 0, r = e.length; n < r; n++) i += e[n].length;
        let t = new Uint8Array(i);
        for (let n = 0, r = 0, a = e.length; n < a; n++) {
            let o = e[n];
            t.set(o, r), r += o.length
        }
        return t
    },
    Xe = {
        assign: oa,
        flattenChunks: _a
    },
    Ti = !0;
try {
    String.fromCharCode.apply(null, new Uint8Array(1))
} catch {
    Ti = !1
}
var ze = new Uint8Array(256);
for (let e = 0; e < 256; e++) ze[e] = e >= 252 ? 6 : e >= 248 ? 5 : e >= 240 ? 4 : e >= 224 ? 3 : e >= 192 ? 2 : 1;
ze[254] = ze[254] = 1;
var ha = e => {
        if (typeof TextEncoder == "function" && TextEncoder.prototype.encode) return new TextEncoder().encode(e);
        let i, t, n, r, a, o = e.length,
            f = 0;
        for (r = 0; r < o; r++) t = e.charCodeAt(r), (t & 64512) === 55296 && r + 1 < o && (n = e.charCodeAt(r + 1), (n & 64512) === 56320 && (t = 65536 + (t - 55296 << 10) + (n - 56320), r++)), f += t < 128 ? 1 : t < 2048 ? 2 : t < 65536 ? 3 : 4;
        for (i = new Uint8Array(f), a = 0, r = 0; a < f; r++) t = e.charCodeAt(r), (t & 64512) === 55296 && r + 1 < o && (n = e.charCodeAt(r + 1), (n & 64512) === 56320 && (t = 65536 + (t - 55296 << 10) + (n - 56320), r++)), t < 128 ? i[a++] = t : t < 2048 ? (i[a++] = 192 | t >>> 6, i[a++] = 128 | t & 63) : t < 65536 ? (i[a++] = 224 | t >>> 12, i[a++] = 128 | t >>> 6 & 63, i[a++] = 128 | t & 63) : (i[a++] = 240 | t >>> 18, i[a++] = 128 | t >>> 12 & 63, i[a++] = 128 | t >>> 6 & 63, i[a++] = 128 | t & 63);
        return i
    },
    da = (e, i) => {
        if (i < 65534 && e.subarray && Ti) return String.fromCharCode.apply(null, e.length === i ? e : e.subarray(0, i));
        let t = "";
        for (let n = 0; n < i; n++) t += String.fromCharCode(e[n]);
        return t
    },
    sa = (e, i) => {
        let t = i || e.length;
        if (typeof TextDecoder == "function" && TextDecoder.prototype.decode) return new TextDecoder().decode(e.subarray(0, i));
        let n, r, a = new Array(t * 2);
        for (r = 0, n = 0; n < t;) {
            let o = e[n++];
            if (o < 128) {
                a[r++] = o;
                continue
            }
            let f = ze[o];
            if (f > 4) {
                a[r++] = 65533, n += f - 1;
                continue
            }
            for (o &= f === 2 ? 31 : f === 3 ? 15 : 7; f > 1 && n < t;) o = o << 6 | e[n++] & 63, f--;
            if (f > 1) {
                a[r++] = 65533;
                continue
            }
            o < 65536 ? a[r++] = o : (o -= 65536, a[r++] = 55296 | o >> 10 & 1023, a[r++] = 56320 | o & 1023)
        }
        return da(a, r)
    },
    ca = (e, i) => {
        i = i || e.length, i > e.length && (i = e.length);
        let t = i - 1;
        for (; t >= 0 && (e[t] & 192) === 128;) t--;
        return t < 0 || t === 0 ? i : t + ze[e[t]] > i ? t : i
    },
    Se = {
        string2buf: ha,
        buf2string: sa,
        utf8border: ca
    };

function ua() {
    this.input = null, this.next_in = 0, this.avail_in = 0, this.total_in = 0, this.output = null, this.next_out = 0, this.avail_out = 0, this.total_out = 0, this.msg = "", this.state = null, this.data_type = 2, this.adler = 0
}
var Di = ua,
    Zi = Object.prototype.toString,
    {
        Z_NO_FLUSH: wa,
        Z_SYNC_FLUSH: ba,
        Z_FULL_FLUSH: ga,
        Z_FINISH: pa,
        Z_OK: Be,
        Z_STREAM_END: xa,
        Z_DEFAULT_COMPRESSION: va,
        Z_DEFAULT_STRATEGY: ka,
        Z_DEFLATED: Ea
    } = de;

function De(e) {
    this.options = Xe.assign({
        level: va,
        method: Ea,
        chunkSize: 16384,
        windowBits: 15,
        memLevel: 8,
        strategy: ka
    }, e || {});
    let i = this.options;
    i.raw && i.windowBits > 0 ? i.windowBits = -i.windowBits : i.gzip && i.windowBits > 0 && i.windowBits < 16 && (i.windowBits += 16), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new Di, this.strm.avail_out = 0;
    let t = pe.deflateInit2(this.strm, i.level, i.method, i.windowBits, i.memLevel, i.strategy);
    if (t !== Be) throw new Error(te[t]);
    if (i.header && pe.deflateSetHeader(this.strm, i.header), i.dictionary) {
        let n;
        if (typeof i.dictionary == "string" ? n = Se.string2buf(i.dictionary) : Zi.call(i.dictionary) === "[object ArrayBuffer]" ? n = new Uint8Array(i.dictionary) : n = i.dictionary, t = pe.deflateSetDictionary(this.strm, n), t !== Be) throw new Error(te[t]);
        this._dict_set = !0
    }
}
De.prototype.push = function(e, i) {
    let t = this.strm,
        n = this.options.chunkSize,
        r, a;
    if (this.ended) return !1;
    for (i === ~~i ? a = i : a = i === !0 ? pa : wa, typeof e == "string" ? t.input = Se.string2buf(e) : Zi.call(e) === "[object ArrayBuffer]" ? t.input = new Uint8Array(e) : t.input = e, t.next_in = 0, t.avail_in = t.input.length;;) {
        if (t.avail_out === 0 && (t.output = new Uint8Array(n), t.next_out = 0, t.avail_out = n), (a === ba || a === ga) && t.avail_out <= 6) {
            this.onData(t.output.subarray(0, t.next_out)), t.avail_out = 0;
            continue
        }
        if (r = pe.deflate(t, a), r === xa) return t.next_out > 0 && this.onData(t.output.subarray(0, t.next_out)), r = pe.deflateEnd(this.strm), this.onEnd(r), this.ended = !0, r === Be;
        if (t.avail_out === 0) {
            this.onData(t.output);
            continue
        }
        if (a > 0 && t.next_out > 0) {
            this.onData(t.output.subarray(0, t.next_out)), t.avail_out = 0;
            continue
        }
        if (t.avail_in === 0) break
    }
    return !0
};
De.prototype.onData = function(e) {
    this.chunks.push(e)
};
De.prototype.onEnd = function(e) {
    e === Be && (this.result = Xe.flattenChunks(this.chunks)), this.chunks = [], this.err = e, this.msg = this.strm.msg
};

function Et(e, i) {
    let t = new De(i);
    if (t.push(e, !0), t.err) throw t.msg || te[t.err];
    return t.result
}

function ya(e, i) {
    return i = i || {}, i.raw = !0, Et(e, i)
}

function ma(e, i) {
    return i = i || {}, i.gzip = !0, Et(e, i)
}
var za = De,
    Sa = Et,
    Aa = ya,
    Ra = ma,
    Ta = de,
    Da = {
        Deflate: za,
        deflate: Sa,
        deflateRaw: Aa,
        gzip: Ra,
        constants: Ta
    },
    Ue = 16209,
    Za = 16191,
    Ia = function(i, t) {
        let n, r, a, o, f, c, l, _, y, s, h, u, T, k, g, S, p, d, m, D, w, A, E, b, x = i.state;
        n = i.next_in, E = i.input, r = n + (i.avail_in - 5), a = i.next_out, b = i.output, o = a - (t - i.avail_out), f = a + (i.avail_out - 257), c = x.dmax, l = x.wsize, _ = x.whave, y = x.wnext, s = x.window, h = x.hold, u = x.bits, T = x.lencode, k = x.distcode, g = (1 << x.lenbits) - 1, S = (1 << x.distbits) - 1;
        e: do {
            u < 15 && (h += E[n++] << u, u += 8, h += E[n++] << u, u += 8), p = T[h & g];
            t: for (;;) {
                if (d = p >>> 24, h >>>= d, u -= d, d = p >>> 16 & 255, d === 0) b[a++] = p & 65535;
                else if (d & 16) {
                    m = p & 65535, d &= 15, d && (u < d && (h += E[n++] << u, u += 8), m += h & (1 << d) - 1, h >>>= d, u -= d), u < 15 && (h += E[n++] << u, u += 8, h += E[n++] << u, u += 8), p = k[h & S];
                    i: for (;;) {
                        if (d = p >>> 24, h >>>= d, u -= d, d = p >>> 16 & 255, d & 16) {
                            if (D = p & 65535, d &= 15, u < d && (h += E[n++] << u, u += 8, u < d && (h += E[n++] << u, u += 8)), D += h & (1 << d) - 1, D > c) {
                                i.msg = "invalid distance too far back", x.mode = Ue;
                                break e
                            }
                            if (h >>>= d, u -= d, d = a - o, D > d) {
                                if (d = D - d, d > _ && x.sane) {
                                    i.msg = "invalid distance too far back", x.mode = Ue;
                                    break e
                                }
                                if (w = 0, A = s, y === 0) {
                                    if (w += l - d, d < m) {
                                        m -= d;
                                        do b[a++] = s[w++]; while (--d);
                                        w = a - D, A = b
                                    }
                                } else if (y < d) {
                                    if (w += l + y - d, d -= y, d < m) {
                                        m -= d;
                                        do b[a++] = s[w++]; while (--d);
                                        if (w = 0, y < m) {
                                            d = y, m -= d;
                                            do b[a++] = s[w++]; while (--d);
                                            w = a - D, A = b
                                        }
                                    }
                                } else if (w += y - d, d < m) {
                                    m -= d;
                                    do b[a++] = s[w++]; while (--d);
                                    w = a - D, A = b
                                }
                                for (; m > 2;) b[a++] = A[w++], b[a++] = A[w++], b[a++] = A[w++], m -= 3;
                                m && (b[a++] = A[w++], m > 1 && (b[a++] = A[w++]))
                            } else {
                                w = a - D;
                                do b[a++] = b[w++], b[a++] = b[w++], b[a++] = b[w++], m -= 3; while (m > 2);
                                m && (b[a++] = b[w++], m > 1 && (b[a++] = b[w++]))
                            }
                        } else if ((d & 64) === 0) {
                            p = k[(p & 65535) + (h & (1 << d) - 1)];
                            continue i
                        } else {
                            i.msg = "invalid distance code", x.mode = Ue;
                            break e
                        }
                        break
                    }
                } else if ((d & 64) === 0) {
                    p = T[(p & 65535) + (h & (1 << d) - 1)];
                    continue t
                } else if (d & 32) {
                    x.mode = Za;
                    break e
                } else {
                    i.msg = "invalid literal/length code", x.mode = Ue;
                    break e
                }
                break
            }
        } while (n < r && a < f);
        m = u >> 3, n -= m, u -= m << 3, h &= (1 << u) - 1, i.next_in = n, i.next_out = a, i.avail_in = n < r ? 5 + (r - n) : 5 - (n - r), i.avail_out = a < f ? 257 + (f - a) : 257 - (a - f), x.hold = h, x.bits = u
    },
    le = 15,
    Ot = 852,
    Nt = 592,
    Lt = 0,
    et = 1,
    Ut = 2,
    Oa = new Uint16Array([3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258, 0, 0]),
    Na = new Uint8Array([16, 16, 16, 16, 16, 16, 16, 16, 17, 17, 17, 17, 18, 18, 18, 18, 19, 19, 19, 19, 20, 20, 20, 20, 21, 21, 21, 21, 16, 72, 78]),
    La = new Uint16Array([1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577, 0, 0]),
    Ua = new Uint8Array([16, 16, 16, 16, 17, 17, 18, 18, 19, 19, 20, 20, 21, 21, 22, 22, 23, 23, 24, 24, 25, 25, 26, 26, 27, 27, 28, 28, 29, 29, 64, 64]),
    Ca = (e, i, t, n, r, a, o, f) => {
        let c = f.bits,
            l = 0,
            _ = 0,
            y = 0,
            s = 0,
            h = 0,
            u = 0,
            T = 0,
            k = 0,
            g = 0,
            S = 0,
            p, d, m, D, w, A = null,
            E, b = new Uint16Array(le + 1),
            x = new Uint16Array(le + 1),
            J = null,
            mt, Ie, Oe;
        for (l = 0; l <= le; l++) b[l] = 0;
        for (_ = 0; _ < n; _++) b[i[t + _]]++;
        for (h = c, s = le; s >= 1 && b[s] === 0; s--);
        if (h > s && (h = s), s === 0) return r[a++] = 1 << 24 | 64 << 16 | 0, r[a++] = 1 << 24 | 64 << 16 | 0, f.bits = 1, 0;
        for (y = 1; y < s && b[y] === 0; y++);
        for (h < y && (h = y), k = 1, l = 1; l <= le; l++)
            if (k <<= 1, k -= b[l], k < 0) return -1;
        if (k > 0 && (e === Lt || s !== 1)) return -1;
        for (x[1] = 0, l = 1; l < le; l++) x[l + 1] = x[l] + b[l];
        for (_ = 0; _ < n; _++) i[t + _] !== 0 && (o[x[i[t + _]]++] = _);
        if (e === Lt ? (A = J = o, E = 20) : e === et ? (A = Oa, J = Na, E = 257) : (A = La, J = Ua, E = 0), S = 0, _ = 0, l = y, w = a, u = h, T = 0, m = -1, g = 1 << h, D = g - 1, e === et && g > Ot || e === Ut && g > Nt) return 1;
        for (;;) {
            mt = l - T, o[_] + 1 < E ? (Ie = 0, Oe = o[_]) : o[_] >= E ? (Ie = J[o[_] - E], Oe = A[o[_] - E]) : (Ie = 96, Oe = 0), p = 1 << l - T, d = 1 << u, y = d;
            do d -= p, r[w + (S >> T) + d] = mt << 24 | Ie << 16 | Oe | 0; while (d !== 0);
            for (p = 1 << l - 1; S & p;) p >>= 1;
            if (p !== 0 ? (S &= p - 1, S += p) : S = 0, _++, --b[l] === 0) {
                if (l === s) break;
                l = i[t + o[_]]
            }
            if (l > h && (S & D) !== m) {
                for (T === 0 && (T = h), w += y, u = l - T, k = 1 << u; u + T < s && (k -= b[u + T], !(k <= 0));) u++, k <<= 1;
                if (g += 1 << u, e === et && g > Ot || e === Ut && g > Nt) return 1;
                m = S & D, r[m] = h << 24 | u << 16 | w - a | 0
            }
        }
        return S !== 0 && (r[w + S] = l - T << 24 | 64 << 16 | 0), f.bits = h, 0
    },
    xe = Ca,
    $a = 0,
    Ii = 1,
    Oi = 2,
    {
        Z_FINISH: Ct,
        Z_BLOCK: Fa,
        Z_TREES: Ce,
        Z_OK: ne,
        Z_STREAM_END: Ma,
        Z_NEED_DICT: Ha,
        Z_STREAM_ERROR: $,
        Z_DATA_ERROR: Ni,
        Z_MEM_ERROR: Li,
        Z_BUF_ERROR: Ba,
        Z_DEFLATED: $t
    } = de,
    Ye = 16180,
    Ft = 16181,
    Mt = 16182,
    Ht = 16183,
    Bt = 16184,
    Kt = 16185,
    Pt = 16186,
    Xt = 16187,
    Yt = 16188,
    Gt = 16189,
    Ke = 16190,
    K = 16191,
    tt = 16192,
    jt = 16193,
    it = 16194,
    Wt = 16195,
    Vt = 16196,
    Jt = 16197,
    Qt = 16198,
    $e = 16199,
    Fe = 16200,
    qt = 16201,
    ei = 16202,
    ti = 16203,
    ii = 16204,
    ni = 16205,
    nt = 16206,
    ai = 16207,
    ri = 16208,
    R = 16209,
    Ui = 16210,
    Ci = 16211,
    Ka = 852,
    Pa = 592,
    Xa = 15,
    Ya = Xa,
    li = e => (e >>> 24 & 255) + (e >>> 8 & 65280) + ((e & 65280) << 8) + ((e & 255) << 24);

function Ga() {
    this.strm = null, this.mode = 0, this.last = !1, this.wrap = 0, this.havedict = !1, this.flags = 0, this.dmax = 0, this.check = 0, this.total = 0, this.head = null, this.wbits = 0, this.wsize = 0, this.whave = 0, this.wnext = 0, this.window = null, this.hold = 0, this.bits = 0, this.length = 0, this.offset = 0, this.extra = 0, this.lencode = null, this.distcode = null, this.lenbits = 0, this.distbits = 0, this.ncode = 0, this.nlen = 0, this.ndist = 0, this.have = 0, this.next = null, this.lens = new Uint16Array(320), this.work = new Uint16Array(288), this.lendyn = null, this.distdyn = null, this.sane = 0, this.back = 0, this.was = 0
}
var ae = e => {
        if (!e) return 1;
        let i = e.state;
        return !i || i.strm !== e || i.mode < Ye || i.mode > Ci ? 1 : 0
    },
    $i = e => {
        if (ae(e)) return $;
        let i = e.state;
        return e.total_in = e.total_out = i.total = 0, e.msg = "", i.wrap && (e.adler = i.wrap & 1), i.mode = Ye, i.last = 0, i.havedict = 0, i.flags = -1, i.dmax = 32768, i.head = null, i.hold = 0, i.bits = 0, i.lencode = i.lendyn = new Int32Array(Ka), i.distcode = i.distdyn = new Int32Array(Pa), i.sane = 1, i.back = -1, ne
    },
    Fi = e => {
        if (ae(e)) return $;
        let i = e.state;
        return i.wsize = 0, i.whave = 0, i.wnext = 0, $i(e)
    },
    Mi = (e, i) => {
        let t;
        if (ae(e)) return $;
        let n = e.state;
        return i < 0 ? (t = 0, i = -i) : (t = (i >> 4) + 5, i < 48 && (i &= 15)), i && (i < 8 || i > 15) ? $ : (n.window !== null && n.wbits !== i && (n.window = null), n.wrap = t, n.wbits = i, Fi(e))
    },
    Hi = (e, i) => {
        if (!e) return $;
        let t = new Ga;
        e.state = t, t.strm = e, t.window = null, t.mode = Ye;
        let n = Mi(e, i);
        return n !== ne && (e.state = null), n
    },
    ja = e => Hi(e, Ya),
    fi = !0,
    at, rt, Wa = e => {
        if (fi) {
            at = new Int32Array(512), rt = new Int32Array(32);
            let i = 0;
            for (; i < 144;) e.lens[i++] = 8;
            for (; i < 256;) e.lens[i++] = 9;
            for (; i < 280;) e.lens[i++] = 7;
            for (; i < 288;) e.lens[i++] = 8;
            for (xe(Ii, e.lens, 0, 288, at, 0, e.work, {
                    bits: 9
                }), i = 0; i < 32;) e.lens[i++] = 5;
            xe(Oi, e.lens, 0, 32, rt, 0, e.work, {
                bits: 5
            }), fi = !1
        }
        e.lencode = at, e.lenbits = 9, e.distcode = rt, e.distbits = 5
    },
    Bi = (e, i, t, n) => {
        let r, a = e.state;
        return a.window === null && (a.wsize = 1 << a.wbits, a.wnext = 0, a.whave = 0, a.window = new Uint8Array(a.wsize)), n >= a.wsize ? (a.window.set(i.subarray(t - a.wsize, t), 0), a.wnext = 0, a.whave = a.wsize) : (r = a.wsize - a.wnext, r > n && (r = n), a.window.set(i.subarray(t - n, t - n + r), a.wnext), n -= r, n ? (a.window.set(i.subarray(t - n, t), 0), a.wnext = n, a.whave = a.wsize) : (a.wnext += r, a.wnext === a.wsize && (a.wnext = 0), a.whave < a.wsize && (a.whave += r))), 0
    },
    Va = (e, i) => {
        let t, n, r, a, o, f, c, l, _, y, s, h, u, T, k = 0,
            g, S, p, d, m, D, w, A, E = new Uint8Array(4),
            b, x, J = new Uint8Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);
        if (ae(e) || !e.output || !e.input && e.avail_in !== 0) return $;
        t = e.state, t.mode === K && (t.mode = tt), o = e.next_out, r = e.output, c = e.avail_out, a = e.next_in, n = e.input, f = e.avail_in, l = t.hold, _ = t.bits, y = f, s = c, A = ne;
        e: for (;;) switch (t.mode) {
            case Ye:
                if (t.wrap === 0) {
                    t.mode = tt;
                    break
                }
                for (; _ < 16;) {
                    if (f === 0) break e;
                    f--, l += n[a++] << _, _ += 8
                }
                if (t.wrap & 2 && l === 35615) {
                    t.wbits === 0 && (t.wbits = 15), t.check = 0, E[0] = l & 255, E[1] = l >>> 8 & 255, t.check = Z(t.check, E, 2, 0), l = 0, _ = 0, t.mode = Ft;
                    break
                }
                if (t.head && (t.head.done = !1), !(t.wrap & 1) || (((l & 255) << 8) + (l >> 8)) % 31) {
                    e.msg = "incorrect header check", t.mode = R;
                    break
                }
                if ((l & 15) !== $t) {
                    e.msg = "unknown compression method", t.mode = R;
                    break
                }
                if (l >>>= 4, _ -= 4, w = (l & 15) + 8, t.wbits === 0 && (t.wbits = w), w > 15 || w > t.wbits) {
                    e.msg = "invalid window size", t.mode = R;
                    break
                }
                t.dmax = 1 << t.wbits, t.flags = 0, e.adler = t.check = 1, t.mode = l & 512 ? Gt : K, l = 0, _ = 0;
                break;
            case Ft:
                for (; _ < 16;) {
                    if (f === 0) break e;
                    f--, l += n[a++] << _, _ += 8
                }
                if (t.flags = l, (t.flags & 255) !== $t) {
                    e.msg = "unknown compression method", t.mode = R;
                    break
                }
                if (t.flags & 57344) {
                    e.msg = "unknown header flags set", t.mode = R;
                    break
                }
                t.head && (t.head.text = l >> 8 & 1), t.flags & 512 && t.wrap & 4 && (E[0] = l & 255, E[1] = l >>> 8 & 255, t.check = Z(t.check, E, 2, 0)), l = 0, _ = 0, t.mode = Mt;
            case Mt:
                for (; _ < 32;) {
                    if (f === 0) break e;
                    f--, l += n[a++] << _, _ += 8
                }
                t.head && (t.head.time = l), t.flags & 512 && t.wrap & 4 && (E[0] = l & 255, E[1] = l >>> 8 & 255, E[2] = l >>> 16 & 255, E[3] = l >>> 24 & 255, t.check = Z(t.check, E, 4, 0)), l = 0, _ = 0, t.mode = Ht;
            case Ht:
                for (; _ < 16;) {
                    if (f === 0) break e;
                    f--, l += n[a++] << _, _ += 8
                }
                t.head && (t.head.xflags = l & 255, t.head.os = l >> 8), t.flags & 512 && t.wrap & 4 && (E[0] = l & 255, E[1] = l >>> 8 & 255, t.check = Z(t.check, E, 2, 0)), l = 0, _ = 0, t.mode = Bt;
            case Bt:
                if (t.flags & 1024) {
                    for (; _ < 16;) {
                        if (f === 0) break e;
                        f--, l += n[a++] << _, _ += 8
                    }
                    t.length = l, t.head && (t.head.extra_len = l), t.flags & 512 && t.wrap & 4 && (E[0] = l & 255, E[1] = l >>> 8 & 255, t.check = Z(t.check, E, 2, 0)), l = 0, _ = 0
                } else t.head && (t.head.extra = null);
                t.mode = Kt;
            case Kt:
                if (t.flags & 1024 && (h = t.length, h > f && (h = f), h && (t.head && (w = t.head.extra_len - t.length, t.head.extra || (t.head.extra = new Uint8Array(t.head.extra_len)), t.head.extra.set(n.subarray(a, a + h), w)), t.flags & 512 && t.wrap & 4 && (t.check = Z(t.check, n, h, a)), f -= h, a += h, t.length -= h), t.length)) break e;
                t.length = 0, t.mode = Pt;
            case Pt:
                if (t.flags & 2048) {
                    if (f === 0) break e;
                    h = 0;
                    do w = n[a + h++], t.head && w && t.length < 65536 && (t.head.name += String.fromCharCode(w)); while (w && h < f);
                    if (t.flags & 512 && t.wrap & 4 && (t.check = Z(t.check, n, h, a)), f -= h, a += h, w) break e
                } else t.head && (t.head.name = null);
                t.length = 0, t.mode = Xt;
            case Xt:
                if (t.flags & 4096) {
                    if (f === 0) break e;
                    h = 0;
                    do w = n[a + h++], t.head && w && t.length < 65536 && (t.head.comment += String.fromCharCode(w)); while (w && h < f);
                    if (t.flags & 512 && t.wrap & 4 && (t.check = Z(t.check, n, h, a)), f -= h, a += h, w) break e
                } else t.head && (t.head.comment = null);
                t.mode = Yt;
            case Yt:
                if (t.flags & 512) {
                    for (; _ < 16;) {
                        if (f === 0) break e;
                        f--, l += n[a++] << _, _ += 8
                    }
                    if (t.wrap & 4 && l !== (t.check & 65535)) {
                        e.msg = "header crc mismatch", t.mode = R;
                        break
                    }
                    l = 0, _ = 0
                }
                t.head && (t.head.hcrc = t.flags >> 9 & 1, t.head.done = !0), e.adler = t.check = 0, t.mode = K;
                break;
            case Gt:
                for (; _ < 32;) {
                    if (f === 0) break e;
                    f--, l += n[a++] << _, _ += 8
                }
                e.adler = t.check = li(l), l = 0, _ = 0, t.mode = Ke;
            case Ke:
                if (t.havedict === 0) return e.next_out = o, e.avail_out = c, e.next_in = a, e.avail_in = f, t.hold = l, t.bits = _, Ha;
                e.adler = t.check = 1, t.mode = K;
            case K:
                if (i === Fa || i === Ce) break e;
            case tt:
                if (t.last) {
                    l >>>= _ & 7, _ -= _ & 7, t.mode = nt;
                    break
                }
                for (; _ < 3;) {
                    if (f === 0) break e;
                    f--, l += n[a++] << _, _ += 8
                }
                switch (t.last = l & 1, l >>>= 1, _ -= 1, l & 3) {
                    case 0:
                        t.mode = jt;
                        break;
                    case 1:
                        if (Wa(t), t.mode = $e, i === Ce) {
                            l >>>= 2, _ -= 2;
                            break e
                        }
                        break;
                    case 2:
                        t.mode = Vt;
                        break;
                    case 3:
                        e.msg = "invalid block type", t.mode = R
                }
                l >>>= 2, _ -= 2;
                break;
            case jt:
                for (l >>>= _ & 7, _ -= _ & 7; _ < 32;) {
                    if (f === 0) break e;
                    f--, l += n[a++] << _, _ += 8
                }
                if ((l & 65535) !== (l >>> 16 ^ 65535)) {
                    e.msg = "invalid stored block lengths", t.mode = R;
                    break
                }
                if (t.length = l & 65535, l = 0, _ = 0, t.mode = it, i === Ce) break e;
            case it:
                t.mode = Wt;
            case Wt:
                if (h = t.length, h) {
                    if (h > f && (h = f), h > c && (h = c), h === 0) break e;
                    r.set(n.subarray(a, a + h), o), f -= h, a += h, c -= h, o += h, t.length -= h;
                    break
                }
                t.mode = K;
                break;
            case Vt:
                for (; _ < 14;) {
                    if (f === 0) break e;
                    f--, l += n[a++] << _, _ += 8
                }
                if (t.nlen = (l & 31) + 257, l >>>= 5, _ -= 5, t.ndist = (l & 31) + 1, l >>>= 5, _ -= 5, t.ncode = (l & 15) + 4, l >>>= 4, _ -= 4, t.nlen > 286 || t.ndist > 30) {
                    e.msg = "too many length or distance symbols", t.mode = R;
                    break
                }
                t.have = 0, t.mode = Jt;
            case Jt:
                for (; t.have < t.ncode;) {
                    for (; _ < 3;) {
                        if (f === 0) break e;
                        f--, l += n[a++] << _, _ += 8
                    }
                    t.lens[J[t.have++]] = l & 7, l >>>= 3, _ -= 3
                }
                for (; t.have < 19;) t.lens[J[t.have++]] = 0;
                if (t.lencode = t.lendyn, t.lenbits = 7, b = {
                        bits: t.lenbits
                    }, A = xe($a, t.lens, 0, 19, t.lencode, 0, t.work, b), t.lenbits = b.bits, A) {
                    e.msg = "invalid code lengths set", t.mode = R;
                    break
                }
                t.have = 0, t.mode = Qt;
            case Qt:
                for (; t.have < t.nlen + t.ndist;) {
                    for (; k = t.lencode[l & (1 << t.lenbits) - 1], g = k >>> 24, S = k >>> 16 & 255, p = k & 65535, !(g <= _);) {
                        if (f === 0) break e;
                        f--, l += n[a++] << _, _ += 8
                    }
                    if (p < 16) l >>>= g, _ -= g, t.lens[t.have++] = p;
                    else {
                        if (p === 16) {
                            for (x = g + 2; _ < x;) {
                                if (f === 0) break e;
                                f--, l += n[a++] << _, _ += 8
                            }
                            if (l >>>= g, _ -= g, t.have === 0) {
                                e.msg = "invalid bit length repeat", t.mode = R;
                                break
                            }
                            w = t.lens[t.have - 1], h = 3 + (l & 3), l >>>= 2, _ -= 2
                        } else if (p === 17) {
                            for (x = g + 3; _ < x;) {
                                if (f === 0) break e;
                                f--, l += n[a++] << _, _ += 8
                            }
                            l >>>= g, _ -= g, w = 0, h = 3 + (l & 7), l >>>= 3, _ -= 3
                        } else {
                            for (x = g + 7; _ < x;) {
                                if (f === 0) break e;
                                f--, l += n[a++] << _, _ += 8
                            }
                            l >>>= g, _ -= g, w = 0, h = 11 + (l & 127), l >>>= 7, _ -= 7
                        }
                        if (t.have + h > t.nlen + t.ndist) {
                            e.msg = "invalid bit length repeat", t.mode = R;
                            break
                        }
                        for (; h--;) t.lens[t.have++] = w
                    }
                }
                if (t.mode === R) break;
                if (t.lens[256] === 0) {
                    e.msg = "invalid code -- missing end-of-block", t.mode = R;
                    break
                }
                if (t.lenbits = 9, b = {
                        bits: t.lenbits
                    }, A = xe(Ii, t.lens, 0, t.nlen, t.lencode, 0, t.work, b), t.lenbits = b.bits, A) {
                    e.msg = "invalid literal/lengths set", t.mode = R;
                    break
                }
                if (t.distbits = 6, t.distcode = t.distdyn, b = {
                        bits: t.distbits
                    }, A = xe(Oi, t.lens, t.nlen, t.ndist, t.distcode, 0, t.work, b), t.distbits = b.bits, A) {
                    e.msg = "invalid distances set", t.mode = R;
                    break
                }
                if (t.mode = $e, i === Ce) break e;
            case $e:
                t.mode = Fe;
            case Fe:
                if (f >= 6 && c >= 258) {
                    e.next_out = o, e.avail_out = c, e.next_in = a, e.avail_in = f, t.hold = l, t.bits = _, Ia(e, s), o = e.next_out, r = e.output, c = e.avail_out, a = e.next_in, n = e.input, f = e.avail_in, l = t.hold, _ = t.bits, t.mode === K && (t.back = -1);
                    break
                }
                for (t.back = 0; k = t.lencode[l & (1 << t.lenbits) - 1], g = k >>> 24, S = k >>> 16 & 255, p = k & 65535, !(g <= _);) {
                    if (f === 0) break e;
                    f--, l += n[a++] << _, _ += 8
                }
                if (S && (S & 240) === 0) {
                    for (d = g, m = S, D = p; k = t.lencode[D + ((l & (1 << d + m) - 1) >> d)], g = k >>> 24, S = k >>> 16 & 255, p = k & 65535, !(d + g <= _);) {
                        if (f === 0) break e;
                        f--, l += n[a++] << _, _ += 8
                    }
                    l >>>= d, _ -= d, t.back += d
                }
                if (l >>>= g, _ -= g, t.back += g, t.length = p, S === 0) {
                    t.mode = ni;
                    break
                }
                if (S & 32) {
                    t.back = -1, t.mode = K;
                    break
                }
                if (S & 64) {
                    e.msg = "invalid literal/length code", t.mode = R;
                    break
                }
                t.extra = S & 15, t.mode = qt;
            case qt:
                if (t.extra) {
                    for (x = t.extra; _ < x;) {
                        if (f === 0) break e;
                        f--, l += n[a++] << _, _ += 8
                    }
                    t.length += l & (1 << t.extra) - 1, l >>>= t.extra, _ -= t.extra, t.back += t.extra
                }
                t.was = t.length, t.mode = ei;
            case ei:
                for (; k = t.distcode[l & (1 << t.distbits) - 1], g = k >>> 24, S = k >>> 16 & 255, p = k & 65535, !(g <= _);) {
                    if (f === 0) break e;
                    f--, l += n[a++] << _, _ += 8
                }
                if ((S & 240) === 0) {
                    for (d = g, m = S, D = p; k = t.distcode[D + ((l & (1 << d + m) - 1) >> d)], g = k >>> 24, S = k >>> 16 & 255, p = k & 65535, !(d + g <= _);) {
                        if (f === 0) break e;
                        f--, l += n[a++] << _, _ += 8
                    }
                    l >>>= d, _ -= d, t.back += d
                }
                if (l >>>= g, _ -= g, t.back += g, S & 64) {
                    e.msg = "invalid distance code", t.mode = R;
                    break
                }
                t.offset = p, t.extra = S & 15, t.mode = ti;
            case ti:
                if (t.extra) {
                    for (x = t.extra; _ < x;) {
                        if (f === 0) break e;
                        f--, l += n[a++] << _, _ += 8
                    }
                    t.offset += l & (1 << t.extra) - 1, l >>>= t.extra, _ -= t.extra, t.back += t.extra
                }
                if (t.offset > t.dmax) {
                    e.msg = "invalid distance too far back", t.mode = R;
                    break
                }
                t.mode = ii;
            case ii:
                if (c === 0) break e;
                if (h = s - c, t.offset > h) {
                    if (h = t.offset - h, h > t.whave && t.sane) {
                        e.msg = "invalid distance too far back", t.mode = R;
                        break
                    }
                    h > t.wnext ? (h -= t.wnext, u = t.wsize - h) : u = t.wnext - h, h > t.length && (h = t.length), T = t.window
                } else T = r, u = o - t.offset, h = t.length;
                h > c && (h = c), c -= h, t.length -= h;
                do r[o++] = T[u++]; while (--h);
                t.length === 0 && (t.mode = Fe);
                break;
            case ni:
                if (c === 0) break e;
                r[o++] = t.length, c--, t.mode = Fe;
                break;
            case nt:
                if (t.wrap) {
                    for (; _ < 32;) {
                        if (f === 0) break e;
                        f--, l |= n[a++] << _, _ += 8
                    }
                    if (s -= c, e.total_out += s, t.total += s, t.wrap & 4 && s && (e.adler = t.check = t.flags ? Z(t.check, r, s, o - s) : me(t.check, r, s, o - s)), s = c, t.wrap & 4 && (t.flags ? l : li(l)) !== t.check) {
                        e.msg = "incorrect data check", t.mode = R;
                        break
                    }
                    l = 0, _ = 0
                }
                t.mode = ai;
            case ai:
                if (t.wrap && t.flags) {
                    for (; _ < 32;) {
                        if (f === 0) break e;
                        f--, l += n[a++] << _, _ += 8
                    }
                    if (t.wrap & 4 && l !== (t.total & 4294967295)) {
                        e.msg = "incorrect length check", t.mode = R;
                        break
                    }
                    l = 0, _ = 0
                }
                t.mode = ri;
            case ri:
                A = Ma;
                break e;
            case R:
                A = Ni;
                break e;
            case Ui:
                return Li;
            case Ci:
            default:
                return $
        }
        return e.next_out = o, e.avail_out = c, e.next_in = a, e.avail_in = f, t.hold = l, t.bits = _, (t.wsize || s !== e.avail_out && t.mode < R && (t.mode < nt || i !== Ct)) && Bi(e, e.output, e.next_out, s - e.avail_out), y -= e.avail_in, s -= e.avail_out, e.total_in += y, e.total_out += s, t.total += s, t.wrap & 4 && s && (e.adler = t.check = t.flags ? Z(t.check, r, s, e.next_out - s) : me(t.check, r, s, e.next_out - s)), e.data_type = t.bits + (t.last ? 64 : 0) + (t.mode === K ? 128 : 0) + (t.mode === $e || t.mode === it ? 256 : 0), (y === 0 && s === 0 || i === Ct) && A === ne && (A = Ba), A
    },
    Ja = e => {
        if (ae(e)) return $;
        let i = e.state;
        return i.window && (i.window = null), e.state = null, ne
    },
    Qa = (e, i) => {
        if (ae(e)) return $;
        let t = e.state;
        return (t.wrap & 2) === 0 ? $ : (t.head = i, i.done = !1, ne)
    },
    qa = (e, i) => {
        let t = i.length,
            n, r, a;
        return ae(e) || (n = e.state, n.wrap !== 0 && n.mode !== Ke) ? $ : n.mode === Ke && (r = 1, r = me(r, i, t, 0), r !== n.check) ? Ni : (a = Bi(e, i, t, t), a ? (n.mode = Ui, Li) : (n.havedict = 1, ne))
    },
    er = Fi,
    tr = Mi,
    ir = $i,
    nr = ja,
    ar = Hi,
    rr = Va,
    lr = Ja,
    fr = Qa,
    or = qa,
    _r = "pako inflate (from Nodeca project)",
    X = {
        inflateReset: er,
        inflateReset2: tr,
        inflateResetKeep: ir,
        inflateInit: nr,
        inflateInit2: ar,
        inflate: rr,
        inflateEnd: lr,
        inflateGetHeader: fr,
        inflateSetDictionary: or,
        inflateInfo: _r
    };

function hr() {
    this.text = 0, this.time = 0, this.xflags = 0, this.os = 0, this.extra = null, this.extra_len = 0, this.name = "", this.comment = "", this.hcrc = 0, this.done = !1
}
var dr = hr,
    Ki = Object.prototype.toString,
    {
        Z_NO_FLUSH: sr,
        Z_FINISH: cr,
        Z_OK: Ae,
        Z_STREAM_END: lt,
        Z_NEED_DICT: ft,
        Z_STREAM_ERROR: ur,
        Z_DATA_ERROR: oi,
        Z_MEM_ERROR: wr
    } = de;

function Ze(e) {
    this.options = Xe.assign({
        chunkSize: 1024 * 64,
        windowBits: 15,
        to: ""
    }, e || {});
    let i = this.options;
    i.raw && i.windowBits >= 0 && i.windowBits < 16 && (i.windowBits = -i.windowBits, i.windowBits === 0 && (i.windowBits = -15)), i.windowBits >= 0 && i.windowBits < 16 && !(e && e.windowBits) && (i.windowBits += 32), i.windowBits > 15 && i.windowBits < 48 && (i.windowBits & 15) === 0 && (i.windowBits |= 15), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new Di, this.strm.avail_out = 0;
    let t = X.inflateInit2(this.strm, i.windowBits);
    if (t !== Ae) throw new Error(te[t]);
    if (this.header = new dr, X.inflateGetHeader(this.strm, this.header), i.dictionary && (typeof i.dictionary == "string" ? i.dictionary = Se.string2buf(i.dictionary) : Ki.call(i.dictionary) === "[object ArrayBuffer]" && (i.dictionary = new Uint8Array(i.dictionary)), i.raw && (t = X.inflateSetDictionary(this.strm, i.dictionary), t !== Ae))) throw new Error(te[t])
}
Ze.prototype.push = function(e, i) {
    let t = this.strm,
        n = this.options.chunkSize,
        r = this.options.dictionary,
        a, o, f;
    if (this.ended) return !1;
    for (i === ~~i ? o = i : o = i === !0 ? cr : sr, Ki.call(e) === "[object ArrayBuffer]" ? t.input = new Uint8Array(e) : t.input = e, t.next_in = 0, t.avail_in = t.input.length;;) {
        for (t.avail_out === 0 && (t.output = new Uint8Array(n), t.next_out = 0, t.avail_out = n), a = X.inflate(t, o), a === ft && r && (a = X.inflateSetDictionary(t, r), a === Ae ? a = X.inflate(t, o) : a === oi && (a = ft)); t.avail_in > 0 && a === lt && t.state.wrap > 0 && e[t.next_in] !== 0;) X.inflateReset(t), a = X.inflate(t, o);
        switch (a) {
            case ur:
            case oi:
            case ft:
            case wr:
                return this.onEnd(a), this.ended = !0, !1
        }
        if (f = t.avail_out, t.next_out && (t.avail_out === 0 || a === lt))
            if (this.options.to === "string") {
                let c = Se.utf8border(t.output, t.next_out),
                    l = t.next_out - c,
                    _ = Se.buf2string(t.output, c);
                t.next_out = l, t.avail_out = n - l, l && t.output.set(t.output.subarray(c, c + l), 0), this.onData(_)
            } else this.onData(t.output.length === t.next_out ? t.output : t.output.subarray(0, t.next_out));
        if (!(a === Ae && f === 0)) {
            if (a === lt) return a = X.inflateEnd(this.strm), this.onEnd(a), this.ended = !0, !0;
            if (t.avail_in === 0) break
        }
    }
    return !0
};
Ze.prototype.onData = function(e) {
    this.chunks.push(e)
};
Ze.prototype.onEnd = function(e) {
    e === Ae && (this.options.to === "string" ? this.result = this.chunks.join("") : this.result = Xe.flattenChunks(this.chunks)), this.chunks = [], this.err = e, this.msg = this.strm.msg
};

function yt(e, i) {
    let t = new Ze(i);
    if (t.push(e), t.err) throw t.msg || te[t.err];
    return t.result
}

function br(e, i) {
    return i = i || {}, i.raw = !0, yt(e, i)
}
var gr = Ze,
    pr = yt,
    xr = br,
    vr = yt,
    kr = de,
    Er = {
        Inflate: gr,
        inflate: pr,
        inflateRaw: xr,
        ungzip: vr,
        constants: kr
    },
    {
        Deflate: Ir,
        deflate: Or,
        deflateRaw: yr,
        gzip: Nr
    } = Da,
    {
        Inflate: mr,
        inflate: zr,
        inflateRaw: Sr,
        ungzip: Lr
    } = Er;
var Ur = yr;
var Cr = mr,
    $r = zr,
    Fr = Sr;
export {
    Rr as a, Tr as b, Dr as c, Ur as d, Cr as e, $r as f, Fr as g
};