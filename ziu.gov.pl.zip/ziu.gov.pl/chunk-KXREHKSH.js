function a(r) {
    let t = r,
        e = Math.floor(Math.abs(r)),
        i = r.toString().replace(/^[^.]*\.?/, "").length;
    return e === 1 && i === 0 ? 1 : i === 0 && e % 10 === Math.floor(e % 10) && e % 10 >= 2 && e % 10 <= 4 && !(e % 100 >= 12 && e % 100 <= 14) ? 3 : i === 0 && e !== 1 && e % 10 === Math.floor(e % 10) && e % 10 >= 0 && e % 10 <= 1 || i === 0 && e % 10 === Math.floor(e % 10) && e % 10 >= 5 && e % 10 <= 9 || i === 0 && e % 100 === Math.floor(e % 100) && e % 100 >= 12 && e % 100 <= 14 ? 4 : 5
}
var o = ["pl", [
        ["a", "p"],
        ["AM", "PM"]
    ], void 0, [
        ["n", "p", "w", "\u015B", "c", "p", "s"],
        ["niedz.", "pon.", "wt.", "\u015Br.", "czw.", "pt.", "sob."],
        ["niedziela", "poniedzia\u0142ek", "wtorek", "\u015Broda", "czwartek", "pi\u0105tek", "sobota"],
        ["nie", "pon", "wto", "\u015Bro", "czw", "pi\u0105", "sob"]
    ],
    [
        ["N", "P", "W", "\u015A", "C", "P", "S"],
        ["niedz.", "pon.", "wt.", "\u015Br.", "czw.", "pt.", "sob."],
        ["niedziela", "poniedzia\u0142ek", "wtorek", "\u015Broda", "czwartek", "pi\u0105tek", "sobota"],
        ["nie", "pon", "wto", "\u015Bro", "czw", "pi\u0105", "sob"]
    ],
    [
        ["s", "l", "m", "k", "m", "c", "l", "s", "w", "p", "l", "g"],
        ["sty", "lut", "mar", "kwi", "maj", "cze", "lip", "sie", "wrz", "pa\u017A", "lis", "gru"],
        ["stycznia", "lutego", "marca", "kwietnia", "maja", "czerwca", "lipca", "sierpnia", "wrze\u015Bnia", "pa\u017Adziernika", "listopada", "grudnia"]
    ],
    [
        ["S", "L", "M", "K", "M", "C", "L", "S", "W", "P", "L", "G"],
        ["sty", "lut", "mar", "kwi", "maj", "cze", "lip", "sie", "wrz", "pa\u017A", "lis", "gru"],
        ["stycze\u0144", "luty", "marzec", "kwiecie\u0144", "maj", "czerwiec", "lipiec", "sierpie\u0144", "wrzesie\u0144", "pa\u017Adziernik", "listopad", "grudzie\u0144"]
    ],
    [
        ["p.n.e.", "n.e."], void 0, ["przed nasz\u0105 er\u0105", "naszej ery"]
    ], 1, [6, 0],
    ["d.MM.y", "d MMM y", "d MMMM y", "EEEE, d MMMM y"],
    ["HH:mm", "HH:mm:ss", "HH:mm:ss z", "HH:mm:ss zzzz"],
    ["{1}, {0}", void 0, "{1} {0}", void 0],
    [",", "\xA0", ";", "%", "+", "-", "E", "\xD7", "\u2030", "\u221E", "NaN", ":"],
    ["#,##0.###", "#,##0%", "#,##0.00\xA0\xA4", "#E0"], "PLN", "z\u0142", "z\u0142oty polski", {
        AUD: [void 0, "$"],
        CAD: [void 0, "$"],
        CNY: [void 0, "\xA5"],
        GBP: [void 0, "\xA3"],
        HKD: [void 0, "$"],
        ILS: [void 0, "\u20AA"],
        INR: [void 0, "\u20B9"],
        JPY: [void 0, "\xA5"],
        KRW: [void 0, "\u20A9"],
        MXN: [void 0, "$"],
        NZD: [void 0, "$"],
        PHP: [void 0, "\u20B1"],
        PLN: ["z\u0142"],
        RON: [void 0, "lej"],
        TWD: [void 0, "NT$"],
        USD: [void 0, "$"],
        VND: [void 0, "\u20AB"]
    }, "ltr", a
];
export {
    o as a
};